import json
import matplotlib.pyplot as plt
import numpy as np

def get_coordinates(filename: str) -> list[tuple[float, float, float]]:
    coordinates = []
    with open(filename) as f:
        data = json.load(f)
    
    for point in data["boxes_3d"]:
        coordinate = [point[0], point[1], point[2]]
        coordinates.append(coordinate)

    return coordinates

if __name__ == "__main__":
    coordinate_list = get_coordinates("ts_001_AreTomo_SART_reconstruction_TiltCor18_refineFlag1_VolZ1800_info_tmp.json")
    coordinates_np = np.array(coordinate_list)

    x = coordinates_np[:, 0]
    y = coordinates_np[:, 1]
    z = coordinates_np[:, 2]

    fig = plt.figure()
    ax = plt.axes(projection="3d")

    ax.scatter3D(x, y, z, s=10)

    plt.show()